# CSEE 4119 Computer Networks

# Chapter 1 - Computer Network and the Internet

## Introduction

Networking is ubiquitous. We use daily for example

- Internet
- WWW
- Wi-Fi
- LTE Network

Also, the challanges that remain:

- Security
- Reliable service in dynamic environment
- Rich near-real time interactive content
- Critical services

### Networking challange

- How to support diverse and ever-changing use cases?
- How to provide near-real-time interactive content?

> 即如何克服用户的多元化，即多种使用情景；以及最大程度降低网络延迟
> 

## What will study

- Application Layer 应用层
    - How to build applications that span multiple computers and use internet to communicate
    - How common Internet applications work (web, video, DNS)
- Transport Layer 传输层
    - How to deliver message accross Internet, including:
        - Establishing communication between computers 计算机之间建立联系
        - Reliably delivering messages 高保障地传送讯息
        - Avoiding congestion despite many uncorrdinated senders 在有过多发送者时避免拥堵
- Network Layer 网络层
    - How to steer data from source to destination 如何将数据从源头引导到目的地
- Link Layer 链接层
    - How to transfer data between direct neighbors, wired and wireless

## What is Internet

### Nuts and bolts view 实质内容

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled.png)

- Billions of connected computing devices (PC, laptop, phones)
    - Hosts = end system 终端
    - running network applications

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%201.png)

- Communication links
    - via fiber 光纤, copper 铜线, radio 广播讯号. satellite 卫星讯号
    - transmission rate: bandwidth

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%202.png)

- Packet Switches
    - Forward packets, which is chunks of data by two ways:
        - network layer routers (not the router in home)
        - link-layer switches

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%203.png)

- ISPs: Internet Service Provider. 互联网服务供应商
    - The interconnect ISPs is the network of the Internet
- Protocols control sending, receiving of messages
    - e.g. TCP, IP, HTTP, 802.11

### Service view 服务内容

- Internet is an infrastructure 基础设施 that provides services to applications:
    - Web, VoIP, email, games…
- Internet provides programming interface to applications 为应用程序提供编程接口
    - Hooks that allow sending and receiving applications to connect to Internet
    
    > 允许发送和接收应用程序链接到web的钩子
    > 
    - provides service options, like postal service:
        - Reliable data delivery from source to destination
        - Unreliable “best effort” data delivery

### What is protocol

- protocols define format, order of messages sent and received among network entities, and actions taken on message transmission, receipt
- All communication activity in Internet governed by protocols

> 协议规定了网络实体之间发送和接收信息的格式和顺序，以及在信息传输、接收时采取的行动。
> 

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%204.png)

<aside>
💡 就像人之间的对话一样，协议的目的是规范请求和相应之间的正确性

</aside>

## Network Edge

- Network edge:
    - Hosts: clients and servers
    - servers often in data centers
- Access networks, physical media:
    - wired, wireless communication links
    - How to connect end system (mobile, computer) to edge router?
        - residential access nets
        - institutional access network (schools, company)
        - mobile access network (基站)
- Network core:
    - Interconnected routers
    - network of network (ISP)

### Access Network: Digital subscriber line (DSL)

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%205.png)

<aside>
💡 Key network challange: 
How to support new applications on deployed technologies?
如何在已经部署的技术上支持最新的应用？

</aside>

- Use existing telephone line to central office DSLAM
    - data over DSL phone line goes to Internet
    - voice over DSL phone line goes to telephone net
- < 16 Mbps upstream transmission rate (typically < 1Mbps)
- < 52 Mbps downstream transmission rate (typically < 10Mbps)
- Also a two-way telephone channel
- The upload/download/telephone channels use different frequencies

> 国内大概十几年前的电话拨号线路。上网方式和打电话类似，计算机拨打特定的电话号码上网。由于是和固定电话共用线路，所以需要在上网的时候把电话线从固定电话上拔下来。同时在上网时也不能打电话。但是在之后有既可以打电话又可以上网的存在，即通过splitter或者部署两条电话线完成。
> 

### Access Network: Cable network

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%206.png)

- Using frequency division multiplexing 频分复用
    - different channels transmitted in different frequency bands
- Difference between Cable and DSL:
    - Cable network shared its line, but DSL is dedicated

<aside>
💡 Key networking challange:
How to efficiently share a common medium?
如何高效的共享媒介？

</aside>

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%207.png)

- Network of cable, fiber attaches home to ISP router
    - homes share access network to cable headend
        - unlike DSL, which has dedicated access to central office
- Hybird fiber coax (HFC) 光纤同轴电缆
    - CMTS controls access of cable modems to shared coax cable segment

### Access network: home network

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%208.png)

<aside>
💡 Key networking challange:
How to connect different types of networks?
如何连接不同类型的网络？

</aside>

### Wireless access network

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%209.png)

- shared wireless access network connects end system to router via base station, also called “access point”

> 无线接入包含了路由器的WiFi和广域范围内的无线信号基站。二者都可以被称为无线基站接入。
> 

### Enterprise access network

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2010.png)

- Used in companies, universities, etc
- mix of wired, wireless link technologies, connecting a mix of switches and routers

<aside>
💡 由于企业级网络接入需要覆盖大范围的室内面积，所以不能使用讯号基站。而是使用多个路由器和交换器，将无线网络拓展到每栋楼的每一层。交换器主要提供有线网络接入和连接路由器。路由器提供无线网络接入。同时交换器也将公司或大学的专用服务器接入。

</aside>

### Access networks: data center networks

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2011.png)

- High-bandwidth links (10s to 100s Gbps) connect hundreds to thousands of servers together, and to internet

### Hosts: send packets of data

Host sending function:

- takes applications message
- breaks into smaller chunks, known as packets, of length L bits
- transmits packet into access network at transmission rate R, aslo known as link capacity or link bandwidth
- packet transmission delay = time needed to transmit L-bit packet into link

$$
=\frac {L(bits)} {R(bits/sec)}
$$

### Physical Media

- bit: propagates between transmitter/receiver pairs 比特是在接收器和发射器之间传输的
- physical link: what lies between transmitter & receiver 物理链路是连接接收器和发射器的
- guided media: signals propagare in solid media: copper, fiber, coax 导向介质是物理链路的材料

### Physical Media: twisted pair, coax, fiber

- Twisted pair (TP) 双绞线
    - two insulated copper wires
        - Category 5: 100 Mbps
        - Category 6: 10 Gbps

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2012.png)

- Coaxial cable 同轴电缆
    - two concentric copper conductors 两个同心的铜导体
    - bidirectional
    - broadband:
        - multiple frequency channels on cable
        - HFC

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2013.png)

- Fiber optic cable
    - glass fiber carrying light pulses, each pulse a bit
    - high-speed operation:
        - high speed point to point transmission
    - low error rate
        - repeater spaced far apart
        - immune to electromagnetic noise

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2014.png)

### Physical media: ratio

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2015.png)

## Network Core

### Internet structure: network of networks - ISP

- End systems connect to Internet via access ISPs (Internet Service Providers)
    - such as residential, company and university ISPs
- Access ISPs in turm must be interconnected
    - so that any two hosts can send packets to each other
- It resulting network of networks is very complex
    - evolution was driven by economics and national policies

Two options to make ISPs interconnect:

1. connect each access ISP to every other access ISP
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2016.png)
    
2. connect each access ISP to one global transit ISP
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2017.png)
    
    > 就像美国的T1 ISP Sprint
    > 
- But one global ISP will have competitors….

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2018.png)

- And for the big country, global ISPs are not enough, so there should be regional networks to connect access net to ISPs

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2019.png)

- Also, for some content provider networks (for example Google, Microsoft, Akamai) may run their own network, to bring services, content close to end users

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2020.png)

- Simplier diagram

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2021.png)

- At the centre: small number of well-connected large networks
    - Tire-I commercial ISPs (e.g. Level 3, Sprint, AT&T, NTT), with national & international coverage
    - content provider network (e.g. Google): private networks that connects its servers to the Internet, often bypassing tier-I, regional ISPs 通常绕过一级及区域级ISP

## Circuit Switching

### Circuit Switching (Usually used in traditional telephone network)

- End to end resources allocated to, reserved for “call” between source & destination
    - In diagram, each link has four circuits
        - call gets 2nd circuit in top link and 1st circuit in right link.
    - It is dedicated resources: no sharing
        - Circuit like guarnteed performance
    - Circuit segement idle while reserved but not used by call 在没有电话的时候空闲，即不和其他人共享线路。

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2022.png)

<aside>
💡 How can we use circuit switching but still support more simultaneous users than we have physical circuits?
在使用线路切换的同时，我们如何实现同时使用的用户人数大于物理线路的个数？

</aside>

### Circuit Switching: FDM versus TDM

- FDM (Frequency Division Multiplexing) 频分复用

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2023.png)

- TDM (Time Division Multiplexing) 时分复用（时间切片）

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2024.png)

<aside>
💡 Dashed line: subdivide for upstream and downstream
Different colours indicates different users

</aside>

### Packet Switching

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2025.png)

### The network Core

- Mesh of interconnected routers
- Packet-switching: hosts break application layer messages into several packets
    - Forward packets from one router to the next, across links on path from source to destination
    - each packet transmitted at full link capacity
        - after transmission, link is available for other packets (including from other sources)

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2026.png)

### Two key network-core functions

- Routing:
    - Determines source-destination route taken by packets
        - routing algorithm
- Forwarding
    - Move packets from router’s input to appropriate router output

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2027.png)

## Packet switching

<aside>
💡 HW1, HW 1, homework1, homework 1
Question 3

</aside>

### Packet switching versus circuit switching

- Packet switching allows more users to use network

<aside>
💡 1 Mb/s link
Each user use 100 kb/s when “active”, and each user active 10% of time
How many users can circuit switching support?

</aside>

- With 100% reliabilty, 10 users can support
- While the company will not only accept 10 users, which is cost-taking

<aside>
💡 Under Packet Switching
With 35 users, what is the probability for active user is greater than 10?

</aside>

$$
\sum^{i=T}_{i=0}\binom N i p^i(1-p)^{N-i}
$$

$$
=\sum^{i=10}_{i=0}\binom {35} {i} 0.1^i 0.9^{35-i} 
$$

$$
=0.9^{35}+{35 \choose 1}0.1*0.9^{34}+{35\choose2}0.1^20.9^{33}+...+{35\choose10}0.1^{10}0.9^{25}
$$

$$
=0.9995757024045502
$$

$$
1-0.9995757024045502=0.0004
$$

### Packet-switching: store-and-forward

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2028.png)

- Takes L/R seconds to transmit L-bit packet into link at R bps
- Store and forward: entire packet must arrive at router before router can transmit it onward
    - buffers the packet until ready to send
    
    > 整个数据包必须完整达到路由之后，路由才可以继续传输
    > 

<aside>
💡 **End-to-end delay of 1 packet:
$2L/R$
Delay for destination to receive all 3 packets:**
$4L/R$     
($2L/R$ is for 3 packets from source to router, last $L/R$ is for the entire packet send to the destination)

</aside>

### Packet-switching: queuing delay, loss

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2029.png)

- If arrival rate (in bit) to link exceeds transmission rate of link for a period of time:
    - **packets will queue in a buffer**
    - **packets can be dropped (lost) if the buffer is full**

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2030.png)

### 4 sources of nodal (per node) delay 四个节点源的延迟原因

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2031.png)

<aside>
💡 $d_{nodal}=d_{proc}+d{queue}+d_{trans}+d_{prop}$

</aside>

- $**d_{proc}$: processing delay**
    - router will check bit error
    - will determine output link
    - the delay typically samller than 1 ms
- $**d_{queue}$: queuing delay**
    - Time waiting at output link for transmission
    - depends on congestion level of router
- $**d_{trans}$: transmission delay**
    - $d_{trans}=L/R$
    - $L = packet\ \ length\ \ (bits)$
    - $R=link\ \ bandwidth\ \ (bps)$
- $**d_{prop}$: propagation delay**
    - $d_{prop}=d/s$
    - $d=length \ \ of\ \ physical\ \ link$
    - $s=propagation\ \ speed \ \ (2*10^8 m/sec)$

### Queueing delay

- **Traffic intensity:**
    - $Traffic\ \ Intensity=La/R$
    - $L = packet\ \ length\ \ (bits)$
    - $R=link\ \ bandwidth\ \ (bps)$
    - $a=average\ \ packet\ \ arrival\ \ rate\ \ (packets\ \ per\ \ second)$

<aside>
💡 La/R ~ 0: avg. queueing delay small
La/R ~ 1: avg. queueing delay large
La/R > 1: the average delay infinite, more packets arriving than can be served

</aside>

### Packet Loss

- queue (buffer) preceding link in buffer has finite capacity
- packet arriving to a full queue will be dropped (lost)
- lost packet may be re-transmitted by previous node, by source end system, but may not

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2032.png)

## Throughput

- Throughput rate (bits/time unit) at which bits transferred between sender/receiver
    - instantaneous: rate at given point in time
    - average: rate over longer period of time
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2033.png)
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2034.png)
    
    <aside>
    💡 木桶效应，平均吞吐量取决于这条线上平均吞吐量最小的管道
    
    </aside>
    
- per connection end-end thoughput:
    
    $$
    min(R_c, R_s, R/10)
    $$
    

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2035.png)

## Protocol layers

- Layers: each layer implements a service
    - Via its own internal-layer actions
    - relting on services provided by layer below.

### Why layering? (Advantage)

- Dealing with complex systems:
    - explicit structure allows identification, relationship of complex system’s pieces
    - modulatization eases maintenance, updating, reuse of system.
        - change of implementation of lay’s service transparent to rest of system
        - e.g. change in gate procedure doesn’t affect rest of system

### Internet protocol stack (5 layers)

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2036.png)

- Application layer:
    - Supporting network applications
        - FTP, SMTP, HTTP…
- Transport layer:
    - process-process data transfer
        - TCP, UDP
- Network layer:
    - Routing of datagrams from source to destination
        - IP, routing portocol
- Link layer:
    - Data transfer between neighboring network elements
        - Ethernet, 802.111 (Wi-Fi), PPP
- Physical layer:
    - bits “on the wire”

### ISO/OSI reference model (7 layers)

- Presentation layer:
    - Allow applications to interpret meaning of data
        - Like encryption, compression. Machine specific conventions
- Session layer:
    - Synchronization, checkpointing, recovery of data exchange

### Encapsulation - How does one packet travel in the Internet

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2037.png)

### Why NOT layering? (Disadvantage)

- Dealing with complex systems:
    - Layering considered harmful
        - upper layer may duplicate functionality of lower
        - upper may not need functionality of lower
        - one layer might want info only visible at another layer

## Networks under attack: security

# Chapter 2 - Application Layer

## Principles of network application

- Possible structure of applications
    - Client-server
    - Peer-to-peer (P2P)

### Client-server architecture

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2038.png)

- Server:
    - always-on host
    - permanent address
    - data centers for scaling
- Clients:
    - Communicate with server
    - May be intermittently connected 间歇性连接
    - May have dynamic IP address
    - do not communicate directly with each other

### P2P Architecture

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2039.png)

- No always-on server
- arbitrary end systems directly communcate
- peers request service from other peers, provide service in return to other peers
    - self scalability - new peers bring new service capacity, as well as new service demands
- peers are intermittently connected and change IP address
    - complex management

### Process communicating 进程交流

- Within same host, two processes communicate using inter-process communication.
- Processes in different hosts communicate by exchanging messages
- Client process: process that initiates communication
- Sercer process: process that waits to be contacted

### Sockets

- Process sends/ receives messages to/from its socket

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2040.png)

### Addressing processes

- To receive messages, process must have identifier
- Host device has unique 32-bit IP address (IPv4)
- Note that the IP address is not sufficient to indentify the process. because there may have several processes on the same host.
- Identifier includes both IP address and port numbers associated with process on host
    - HTTP server: 80 in default
    - Mail server: 25 in default
- Example, to send HTTP message to gaia.cs.umass.edu:
    - 128.119.245.12:80

### Application layer protocol defines

- Types of message exchanged
    - Request, response
- Message syntax
    - What fields in messages & how fields are delineated
- Messsage semantics
    - Meaning of informations in fields
- Rules
    - For when and how processes send & respond to messages
- Open protocols
    - Defined in RFCs
    - Allows for interoperability
    - HTTP, SMTP
- Proprietary protocols
    - Skype

### Apps need for transport service

- Data integrity 数据完整性
    - Some app require 100% reliable data transfer
        - Downloading, file transfering
    - Other apps do not require (VOIP)
- Timing 延迟
    - Some app require low delay
        - VOIP
- Throughput 吞吐量
    - Require minimum amount of throughput to be effective
        - Media
- Security

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2041.png)

## Internet transport protocols services

### TCP service:

- Provides:
    - Reliable transport between sending and receiving process
    - Flow control: Sender will not overwhelm receiver 传输控制，控制速度以匹配发送者和接收者
    - Congestion control: throttle sender when network overloaded 堵塞控制，当有其他大流量时限制速度
- Do not provide:
    - Timing
    - Minimum throughput guarntee
    - Security

> 适合大流量，文件传输
> 

### UDP service:

- Provides:
    - Unreliable data transfer (?)
- Do not provide:
    - reliable
    - flow control
    - congestion control
    - Throughput guarntee
    - security
    - connection setup

> 适合VOIP
> 

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2042.png)

### Securing TCP

- TCP and UDP has no encryption
- SSL/TLS provides encrypted TCP connection, data integrity, end-point authentication
- SSL is older, TLS is at application layer
    - App use SSL libraries talk to TCP
    - Client or server negotiate use of TLS

## Web and HTTP

### Web Overview

- Web page consists of objects
- object can be HTML file, JPEG file, Java applet, audio file….
- web page need to consists a base HTML-file which includes several referenced objects
- each object is addressable by a URL

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2043.png)

### HTTP Overview

- HTTP: Hypertext Transfer Protocol超文本传输协议
- Client/server model
    - Client: broswer that requests, receives, (using HTTP protocol) and “displays” Web objects
    - Server: Web server sends (using HTTP protocol) objects in response to requests
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2044.png)
    
- Using TCP:
    1. Client initiates TCP connection, usually port 80
    2. server accepts TCP connection from client
    3. HTTP messages (application-layer protocol messages exchanged between broswer (HTTP client) and Web server (HTTP server)
    4. TCP connection closed
- HTTP is stateless
    - From perspective of protocol, server maintains no information about past client requests

### HTTP connections

- Non-persistent HTTP 非持久性HTTP
    - at most one object sent over TCP connection
    - connection then closed
    - downloading multiple objects required multiple connections
- Persistent HTTP 持久性HTTP
    - multiple objects can be sent over single TCP connection between client and server

### Non-persistent HTTP

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2045.png)

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2046.png)

### Non-persistent HTTP: response time

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2047.png)

- Round Trip Time (RTT) definition:
    - Time for a small packet to travel client to server and back
- From ELEN30024 Data Networking:
    
    ### TCP Handshake
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2048.png)
    
    - SEQ means the sequence number
    - ACK means acknowledge signal
    - Round trip time = RTT
    1. Host 1 send SYN=1 to determine that Host 1is available and ask to Host 2 whether it is available, and send the SEQ=x
    2. Host 2 send positive signal with SYN=1, with it’s SEQ=y. ACK=x+1 means that Host 2 got Host 1’s segment x. And, Host 2 expect Host 1 send ACK=y+1 to acknowledge
    3. Host 1 send SEQ=x+1 and ACK=y+1 to determine that Host 1 got Host 2’s segment y.
- HTTP response time:
    - one RTT to initiate TCP connection
    - one RTT for HTTP request and first few bytes of HTTP response to return
    - file transmission time
- Non-persistent HTTP response time = 2RTT+file transmission time

### Persistent HTTP and Non-persistent HTTP

- Non-persistent HTTP issues:
    - requires 2RTT per object
    - OS overhead for each TCP connection 每个TCP链接都会消耗OS的资源
    - broswer often open parallel TCP connection to fetch referenced objects
- Persistent HTTP
    - server leaves connection open after sending response
    - subsequent HTTP messages between same client/server sent over connection
    - client sends requests as soon as it encounters a referenced object
    - as little as one RTT for all the reference objects

### HTTP request message

- Two types of HTTP message
    - request
    - response
- Request message:
    - ASCII (human-readable format)
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2049.png)
    

### HTTP request message: general format

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2050.png)

### HTTP request message: uploading form input

- POST method
    - web page often includes input
    - input is uploaded to server in entity body
- URL method
    - uses GET method
    - input is uploaded in URL field

### Method types

- HTTP 1.0
    - GET
    - POST
    - HEAD
        - Ask server to leave requested object out of response
- HTTP 1.1
    - GET, POST, HEAD
    - PUT
        - upload file in entity body to path specified in URL field
    - DELETE
        - delete file specified in the URL field

### HTTP response message

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2051.png)

### HTTP response status code

200 → OK

request succeeded, requested object later in this msg

301 → Moved permanently

requested object moved, new location specified later in this message (Location:)

400 → Bad request

Requested msg not understood by server

404 → Not found

requested document not found on this server

505 → HTTP version not supported

### Cookies: keeping state

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2052.png)

### User-server state: cookies

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2053.png)

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2054.png)

### Web caches (proxy server)

<aside>
💡 Goal: satisfy request without involving origin server

</aside>

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2055.png)

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2056.png)

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2057.png)

## Electronic Mail

- Three major components:
    - User agents
    - mail servers
    - simple mail transfer protocol (SMTP)
- User agent
    - A mail reader
    - composing, editing, reading mail messages
    - outgoing, incoming messages stored on server
- Mail server
    - mailbox contains incoming messages for each user
    - message queue of outgoing messages
- SMTP (Simple Mail Transfer Protocol
    - Send email messages between mail servers
    - client is the sending mail server
    - “server” is the receiving mail server

### SMTP

- SMTP uses TCP to reliably transfer email message from client to server, default in port 25
- direct transfer: sending server to receiving server
- There are three phases to tansfer:
    1. handshaking 握手信号
    2. transfer of messages 
    3. closure
- command or response interaction (like HTTP)
    - ASCII text as the command
    - status code and phrase as response
- message must be in 7-bit ASCII

### Scenario: Alice sends message to bob

1. Alice uses UA (user agent) to compose message to xx@xxxx.com
2. Alice’s UA sends message to her mail server via SMTP. Message placed in message queue.
3. client side of SMTP opens TCP connection with receiver (AKA router server or Bob’s mail server) 
4. SMTP client sends Alice’s message over the TCP connection
5. Bob’s mail server places the message in mailbox
6. Bob invoke his UA to read message 

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2058.png)

- Sample SMTP interaction

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2059.png)

### SMTP: final words

- SMTP uses persistent connections
- SMTP requires message (header & body) to be in 7-bit ASCII
- SMTP server uses CRLF.CRLF to determine the end of message
- Comparison with HTTP:
    - HTTP: pull
    - SMTP: push
    - both have ASCII command/response interaction, status codes
    - HTTP: each object encapsulated 封装 in its own response message
    - SMTP: multiple objects sent in multipart message, encoded in ASCII

### Mail message format

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2060.png)

SMTP is the protocol for exchanging email messages

- Header lines:
    - From
    - Rcpt to:

RFC 822 is a standard for text message format:

- header lines, e.g.
    - To:
    - From:
    - Subject:
- Body: the “message”
    - ASCII characters only

### Mail access protocols

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2061.png)

- SMTP: delivery and storage to receiver’s server
- mail access protocol: retrieval from server:
    - POP (Post Office Protocol): authorization, download
    - IMAP (Internet Mail Access Protocal): More features than POP, like manipulation of stored message s on server
    - HTTP: gmail, Hotmail, Yahoo mail

### POP3 Protocal

- Authorization phase
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2062.png)
    
    - client commands:
        - User: declare username
        - pass: passwd
    - server responses
        - +OK
        - -ERR
- Transaction phase, client:
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2063.png)
    
    - list: list message numbers
    - retr: retrieve message by number
    - dele: delete
    - quit
- Download and delete Mode:
    - cannot re-read the email if the client has changed
- Download and keep mode:
    - copies of messages on different clients
- POP3 is stateless across sessions

### Features between POP3, IMAP and web mail

| POP3 | IMAP | Web mail |
| --- | --- | --- |
| Once download from server, cannot re-read on other client under download and delete mode
Will have download and keep mode to allow to save message on multiple devices | Keep all messages (email) at the server | Send/receive mail via HTTP to mail server
Mail server communicate each other use SMTP |
|  | Allow user to organize messages in folders |  |
| Stateless across session | Keep user state across sessions |  |

## DNS - Domain Name System

<aside>
💡 Each object has identifiers:
For people, name and passport are identifiers
For Internet Hosts and Routers, IP address and domain name are identidiers
The question that the DNS need to handle is that, how to map between the IP address and the domain name?
DNS存储IP地址和主机万维网（WWW）地址的映射

</aside>

- Domain Name System (DNS)
    - distributed database
        - implementated in hierarchy of many name servers
    - application-layer protocol
        - hosts, name server communicate to resole names
        - core Internet function implemented as application layer protocol
        - used by many other applications and app-layer protocols
        - complexity at network’s “edge”

### DNS name resolution: client view

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2064.png)

- For example, the host at “ee.columbia.edu” wants the IP address for “gaia.cs.umass.edu”
    - The host of “ee.columbia.edu” asks local DNS server
        - Which is usually hosted at local ISP
        - UDP port 53
    - For client’s perspective, local DNS server responds with answer:
        - rest of DNS system is a black box for client

### DNS: services, structure

- DNS services
    - Hostname to IP address translation
    - Host aliasing 主机别名
        - canonical, alias names 典型的，别名的名字
    - mail server aliasing
    - load distribution 负载均衡
        - replicated Web servers: many IP address correspond to one name 将多个IP地址映射到同一个主机名
- Why DNS is distributed not centralized?
    - single point of failure
    - traffic volume
    - distant centralized database
    - maintenance/updates

### DNS: a distributed, hierarchical database分布式的、分层的数据库

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2065.png)

### DNS: Root Name Servers

- DNS root name server contacted by local name server that cannot resolve name
    - root name server can contact any, regardless of what query
    - root server IP addresses loaded into ISP’s resolver

> DNS根服务器由无法解析主机名称的本地DNS服务器联系
只有在本地名称服务器不能解析时，才会和根服务器通信
> 

<aside>
💡 全世界有13台逻辑DNS根服务器，其中为1台主根服务器和12台辅根服务器。并在多个国家有根服务器的镜像

</aside>

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2066.png)

### TLD, authoritative servers 顶级域名服务器，权威DNS服务器

- TLD (top-level domain) servers 顶级域名服务器
    - com, org, net, edu and all top-level country domain
    
    > 顶级域名像com，顶级国家域名像uk, cn
    > 
    - VeriSign maintains servers for .com TLD
    - Educause for .edu TLD
- authoritative DNS servers 权威DNS服务器
    - orgnisation’s own DNS servers, providing authoritative hostname to IP mappings for organisation’s name hosts
    - every organisation with publicly accessible hosts must provide publicly accessible DNS records to map hosts to IP address
    - can be maintained by organisation or service provideer
    
    > 权威DNS服务器由组织或服务供应商提供及维护（Cloudflare, DNSpod），必须提供可公开访问的DNS记录以映射IP地址和主机名
    > 

### Local DNS name server 本地DNS服务器

- Does not strictly belong to hierarchy 本地DNS服务器并不属于严格意义上的分层制度中
- Each ISP (residential ISP, company, university) has one
    - also called “default name server”
    - also public DNS server
        - Google public DNS (8.8.8.8), cloudflare DNS (1.1.1.1)
- when host makes a DNS query, query is sent to its local DNS server
    - The local DNS server has local cache of recent name-to-address mapping (may out of date)
    - The local DNS server acts as proxy, forwards query into hierarchy

### DNS name resolution example DNS解析举例

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2067.png)

### DNS: caching, updating records

- Once name server learns mapping, it caches mapping
    - cache entries timeout after specific time (TTL)
    - TLD servers typically cached in local name servers
- cached entries may out of date
- update and notify mechanisms proposed IETF standard (RFC 2136)

### DNS records

- Distributed database storintg resource records (RR)
    - RR format: (name, value, type, ttl)
    - Type = A (A记录)
        - 主机名和IP地址的映射被称作A记录
        - name is hostname, value is IP address
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2068.png)
    
    - Type = CNAME (CNAME记录)
        - 主机名的别名
        - name is alias name
        - value is canonical name
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2069.png)
    
    - Type = NS
        - 即标明主机使用的命名服务器名称
        - Name is domain
        - value is hostname of authoritative name server for this domain
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2070.png)
    
    - Type = MX
        - value is name of mailserver associated with name
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2071.png)
    

### DNS protocol, messages

- query and reply messages, both with same message format

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2072.png)

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2073.png)

### Inserting records into DNS

- example: new startup “Network Utopia”
- register name [networkutopia.com](http://networkutopia.com) at DNS registrar
    - provide names, IP addresses of authoritative name server (primary and secondary)
    - registrar inserts two RRs into .com TLD server
- create authoritative server type A record for www.networkuptopia.com; type MX record for networkutopia.com

### Attacking DNS

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2074.png)

## P2P applications

### Pure P2P architecture

- no always-on server
- arbitrary end systems directly communicate 终端之间的直接通讯
- peers are intermittently connected and change IP addresses
- For example:
    - File distribution - BitTorrent
    - PPTV (Streaming)
    - VoIP
    
    ![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2075.png)
    

### File distribution: client-server vs P2P

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2076.png)

- Server transmission: must sequentially send (upload) N file copies from server
    - time to send one copy: $F/u_s$
    - Time to send N copies at one time: $FN/u_s$
- Client: each client must download file copy
    - $d_{min}=$ min client download rate
    - $F/d_{min}=$ max download time
- Time to distribute a file F to N client using client-server approach:

$$
D_{c-s}\ge max\{NF/u_s, F/d_{min}\}
$$

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2077.png)

### P2P file distribution: BitTorrent

- File is divided into chunks, e.g. of 256kb each
- peers in torrent send/receive file chunks

![Untitled](CSEE%204119%20Computer%20Networks%208a4ff224462342f7a098188a5c971d9b/Untitled%2078.png)

- peer joining torrent:
    - has no chunks, but will accumulate them over time from other peers (download)
    - registers with tracker to get list of peers, connects to subset of peers (neighbors)
- while downloading, peer uploads chucks to other peers
- peer may change peers with whom it exchange chunks
- churn: peers may come and go
- once peer has entire file. it may leave or remain to seeding

### BitTorrent: requesting, sending file chunks

## Video streaming and content distribution networks